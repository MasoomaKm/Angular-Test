import { Component } from '@angular/core';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-show-data',
  templateUrl: './show-data.component.html',
  styleUrls: ['./show-data.component.scss']
})
export class ShowDataComponent {

  users: any ={ };

  constructor(private apiService: ApiService ){

  }

  ngOnInit(){
    this.loadData();
  }

  loadData(){
    this.apiService.getUserData().subscribe(res => {
      // console.log(res);
      this.users = res;
    })
  }

}
