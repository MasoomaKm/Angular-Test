import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ShowDataComponent } from './show-data/show-data.component';
import { FormDataComponent } from './form-data/form-data.component';
import { FormsModule } from '@angular/forms';
import { OrderDataComponent } from './order-data/order-data.component';

@NgModule({
  declarations: [
    AppComponent,
    ShowDataComponent,
    FormDataComponent,
    OrderDataComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
