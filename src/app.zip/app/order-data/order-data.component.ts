import { Component } from '@angular/core';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-order-data',
  templateUrl: './order-data.component.html',
  styleUrls: ['./order-data.component.scss']
})
export class OrderDataComponent {
  

  orders: any ={ };

  constructor(private apiService: ApiService ){

  }

  ngOnInit(){
    this.loadData();
  }


  loadData(){
    this.apiService.getOrderData().subscribe(
      (res) => {
        this.orders = res;
      },
      (error) => {
        if (error.status === 404) {
          console.log('404 Not Found Error: Data not found.');
        } 
      }
    );
  }
}
