import { Component } from '@angular/core';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-form-data',
  templateUrl: './form-data.component.html',
  styleUrls: ['./form-data.component.scss']
})
export class FormDataComponent {


  constructor(private apiService: ApiService){

  }

  formData ={
    name: '',
    username: '',
    email: '',
  }

  onSubmit(){
    console.log('submitted data', this.formData);
    this.apiService.postData(this.formData);
  }

}
