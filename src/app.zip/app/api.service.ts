import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  constructor(private http: HttpClient) { }

  apiUrl ='https://jsonplaceholder.typicode.com/users';
  ordersApiUrl ='https://jsonplaceholder.typicode.com/orders';


  getUserData(){
    return this.http.get(this.apiUrl);
  }


  getOrderData(){
    return this.http.get(this.ordersApiUrl).pipe(
      catchError((error: any) => {
        console.error('Error:', error);
        throw error;
      })
    );
  }


  postData(formData: any){
    return this.http.post(this.apiUrl, formData);
  }

}
